const firebaseConfig = {
    apiKey: "AIzaSyCmdk-UWV3t8NnvWy6U9JkyDal5vKt0Xqw",
    authDomain: "fir-test-50176.firebaseapp.com",
    projectId: "fir-test-50176",
    storageBucket: "fir-test-50176.firebasestorage.app",
    messagingSenderId: "556494074959",
    appId: "1:556494074959:web:1e7f4846123fd2df34e63a"
};
firebase.initializeApp(firebaseConfig);